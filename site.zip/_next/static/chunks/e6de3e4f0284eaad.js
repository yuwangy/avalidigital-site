__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/e0c8ab8c63dd7928.js",
  "static/chunks/turbopack-0df7f790255c7e3c.js"
])
