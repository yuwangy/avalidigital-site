__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/e0c8ab8c63dd7928.js",
  "static/chunks/turbopack-3cfd9cbbbd2a5cdb.js"
])
